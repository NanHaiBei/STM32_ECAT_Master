#include <stdio.h>
#include <string.h>
//#include "osal.h"
//#include "oshw.h"
#include "ethercattype.h"
#include "ethercatbase.h"
#include "ethercatmain.h"
//#include "ethercatfoe.h"



//void ecat_dm3e_556_read_write(struct ecx_contextt_t *context, uint16 slave);
int ecat_dm3e_556_init(ecx_contextt *context, uint16 slave);
